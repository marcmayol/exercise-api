Exercise API - dataset completo
Generado: 2026-08-05
Ejercicios: 126
Web: https://marcmayol.com/exercise-api

Contenido:
  v1/           JSON: dataset.json (todo en 1 archivo), fichas por ejercicio,
                indices por grupo / musculo / equipamiento, taxonomias.
  images/       Ilustraciones -m.jpg (hombre) y -f.jpg (mujer) por ejercicio.
  muscle-maps/  Mapa muscular SVG por ejercicio (principal naranja, secundario claro).

Empieza por v1/dataset.json (todas las fichas) o v1/exercises.json (indice).

Licencia: ilustraciones y datos propios, uso libre. Mapas musculares a partir de
react-native-body-highlighter (MIT). Hecho por Marc Mayol desde Mallorca.
